import { setupLogin } from './login.js';

document.addEventListener('DOMContentLoaded', () => {
    setupLogin();
});